BookMigration
=============

Simple app that demonstrates Core Data migration. 


##Credits
Thanks to [Gideon Wald](mailto:gideon@welkinhealth.com) and [Benedikt Hirmer](https://github.com/bhr) for pointing out an issue with SQLite's [write-ahead logging](https://github.com/hwaxxer/BookMigration/commit/baa5014391081e7b74223250281e3cad90603c56). 

# UITableView-DXTemplateLayoutCell

base from 
[UITableView-FDTemplateLayoutCell](https://github.com/forkingdog/UITableView-FDTemplateLayoutCell) 1.3 

commit [a71e1f75edde5f54fcaecf226f5e9dcf0f1ad4db](https://github.com/forkingdog/UITableView-FDTemplateLayoutCell/tree/a71e1f75edde5f54fcaecf226f5e9dcf0f1ad4db)

Template auto layout cell for automatically UITableViewCell height calculating. Swift version for UITableView-FDTemplateLayoutCell

//
//  AppDelegate.h
//  TableView
//
//  Created by appledev094 on 3/25/16.
//  Copyright © 2016 PwC Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


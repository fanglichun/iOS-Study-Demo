//
//  main.m
//  TableView
//
//  Created by appledev094 on 3/25/16.
//  Copyright © 2016 PwC Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
